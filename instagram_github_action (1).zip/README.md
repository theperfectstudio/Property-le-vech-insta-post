# Instagram Auto Post via GitHub Actions

## Setup

1. Upload your `service-account-key.json` (Firebase Admin SDK) to the root.
2. Go to your GitHub repo > Settings > Secrets and Variables > Actions:
   - Add `ACCESS_TOKEN` with your Instagram long-lived token
   - Add `IG_USER_ID` with your Instagram Business Account ID

3. GitHub Action will run daily at 10 AM UTC or can be triggered manually.

## To trigger manually

Go to the `Actions` tab > `Post to Instagram` > Run workflow.